<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row justify-content-center">
    <div class="col-md-8">
      <div class="card">
        <div class="card-header">Dashboard</div>

        <div class="card-body">

          <table class="table table-bordered">
            <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col">Nombre</th>
                <th scope="col">Email</th>
                <th scope="col">Confirmado</th>
                <th scope="col">Acciones</th>


              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php echo $__env->make('admin.users.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              <tr>
                <th scope="row"><?php echo e($user->id); ?></th>
                <td><?php echo e($user->name); ?></td>
                <td><?php echo e($user->email); ?></td>
                <td><?php echo e(implode('. ',$user->roles()->get()->pluck('name')->toArray())); ?></td>
                <td>
                  <a href="<?php echo e(route('admin.users.edit', $user->id)); ?> ">
                    <button type="button" class="btn btn-primary btn-sm">Editar</button>
                  </a>
                  <a><button data-target="#modal-delete-<?php echo e($user->id); ?>" data-toggle="modal"
                    class="btn btn-danger">Borrar</button></a>

              </td>

              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </tbody>
          </table>

        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\cyber\Desktop\tallerfinal\taller\resources\views/admin/users/index.blade.php ENDPATH**/ ?>