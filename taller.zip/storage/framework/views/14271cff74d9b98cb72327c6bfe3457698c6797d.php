<?php $__env->startSection('content'); ?>

<div class="row mb-3">
    <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12 text-center ">
    <h2>Listado de Reparaciones</h2>


    </div>

</div>
<div class="row">
    <div class="col-12">
        <div class="">
            <table class="table table-bordered">
                <thead>
                    <th scope="col"  >ID</th>
                    <th>Matricula</th>                    
                    <th scope="col">Desrepara</th>
                    <th scope="col">  Fecha </th>
                    <th scope="col">Kilometros</th>                    
                </thead>

                <?php $__currentLoopData = $reparations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reparation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               
               
                <tr>
                    <td class=""><?php echo e($reparation->id); ?> </td>
                    <td class=""><?php echo e($reparation->matricula); ?> </td>
                    
                    <td ><?php echo e($reparation->desrepara); ?> </td>
                    <td  class=""><?php echo e(Carbon::parse($reparation->fecha)->formatLocalized('%d %m %Y')); ?> </td>
                    <td  class=""><?php echo e($reparation->kilometros); ?> </td>
                    
                </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </table>
        </div>
        <?php echo e($reparations->render()); ?>



    </div>


</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\cyber\Desktop\tallerfinal\taller\resources\views/reparation/index.blade.php ENDPATH**/ ?>