<?php $__env->startSection('content'); ?>

<div class="row mb-3">
    <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12 text-center ">
        <h2>Listado de Reparaciones <a href="reparations/create"><button class="btn btn-primary"><i class="fas fa-car-crash"></i> Añadir
            Reparacion</button></a>
</h2>
        
        <?php echo $__env->make('admin.reparations.search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        

    </div>

</div>
<div class="row">
    <div class="col-12">
        <div class="">
            <table class="table table-bordered">
                <thead>
                    <th scope="col">ID</th>
                    <th>Matricula</th>
                    <th>Codigo</th>
                    <th scope="col">Desrepara</th>
                    <th scope="col"> Fecha </th>
                    <th scope="col">Kilometros</th>
                    <th>Editar / Borrar</th>
                </thead>

                <?php $__currentLoopData = $reparations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reparation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('admin.reparations.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php
                    $matr=Str_split($reparation->matricula ,1);
                    $final="";
                    for ($a=0;$a<count($matr);$a++){
                        $final .= ord($matr[$a]).'*';		
                    }
                    ?>


                <tr>
                    <td class=""><?php echo e($reparation->id); ?> </td>
                    <td class=""><?php echo e($reparation->matricula); ?> </td>
                    <td class=""><?php echo e($final); ?> </td>
                    <td><?php echo e($reparation->desrepara); ?> </td>
                    <td class=""><?php echo e(Carbon::parse($reparation->fecha)->formatLocalized('%d %m %Y')); ?> </td>
                    <td class=""><?php echo e($reparation->kilometros); ?> </td>
                    <td>
                        <a href="reparations/<?php echo e($reparation->id); ?>/edit"><button class="btn btn-info" data-toggle="tooltip" data-placement="top" title="Editar/Modificar reparacion"><i class="far fa-edit"></i></button></a>
                        <a data-toggle="tooltip" data-placement="top" title="Borrar reparacion"><button data-target="#modal-delete-<?php echo e($reparation->id); ?>" data-toggle="modal"
                                class="btn btn-danger"><i class="fas fa-ban"></i></button></a>


                    </td>

                </tr>
                
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                
            </table>
            <?php echo e($reparations->appends(['searchText' => $searchText])->render()); ?>

        </div>
       


    </div>


</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\cyber\Desktop\tallerfinal\taller\resources\views/admin/reparations/index.blade.php ENDPATH**/ ?>