<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Listado de Reparaciones</title>
    <style>
        *{
            text-align: center;

        }
        td {
            font-size: 12px;
            

        }
        .table{
            width: 100%;
        }

        .headtable {
           
            border: 1px solid #000000;
            

        }

        .linea {
            border: 1px solid #000000;

        }
    </style>
</head>

<body>
    <h2>Listado de Reparaciones</h2>

    <h3>Busqueda: <?php echo e($searchText); ?></h3>
    <table class="table">


        <thead class="headtable">

            <tr>
                <th>ID</th>
                <th>Matricula</th>
                <th>Codigo</th>
                <th>Reparacion</th>
                <th> Fecha </th>
                <th>Kilometros</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $reparations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reparation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr>
                <?php
                                    $matr=Str_split($reparation->matricula ,1);
                                    $final="";
                                    for ($a=0;$a<count($matr);$a++){
                                        $final .= ord($matr[$a]).'|';		
                                    }
                                    ?>
                <td><?php echo e($reparation->id); ?> </td>
                <td><?php echo e($reparation->matricula); ?> </td>
                <td><?php echo e($final); ?> </td>
                <td><?php echo e($reparation->desrepara); ?> </td>
                <td><?php echo e(Carbon::parse($reparation->fecha)->formatLocalized('%d %m %Y')); ?> </td>
                <td><?php echo e($reparation->kilometros); ?> </td>


            </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



        </tbody>



    </table>


</body>

</html><?php /**PATH C:\Users\cyber\Desktop\tallerfinal\taller\resources\views/admin/pdf/reparations.blade.php ENDPATH**/ ?>