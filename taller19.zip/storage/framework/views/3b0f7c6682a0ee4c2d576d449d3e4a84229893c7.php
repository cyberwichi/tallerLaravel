<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Autorizar Usuario <strong><?php echo e($user->name); ?></strong> </div>
                <div class="card-body">
                    <form action="<?php echo e(route('admin.users.update', ['user'=>$user->id])); ?> " method="POST">
                    <?php echo e(csrf_field()); ?>

              
                    <?php echo e(method_field('PUT')); ?>

                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-check">
                            <input type="checkbox" name="roles[]" value="<?php echo e($role->id); ?>"
                            <?php echo e($user->hasAnyRole($role->name)?'checked':''); ?>>
                        <label>Autorizado</label>
                        </div>                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <button type="submit" class="btn btn-primary">Modificar</button>
                    
                    
                    </form>



                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\cyber\Desktop\tallerfinal\taller\resources\views/admin/users/edit.blade.php ENDPATH**/ ?>