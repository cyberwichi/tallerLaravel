<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row justify-content-center">
    <div class="col-md-8">
      <div class="card">
        <div class="card-header">Usuarios del Sistema</div>

        <div class="card-body">

          <table class="table table-bordered">
            <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col">Nombre</th>
                <th scope="col">Email</th>
                <th scope="col">Autorizado</th>
                <th scope="col">Acciones</th>


              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php echo $__env->make('admin.users.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              <tr>
                <th scope="row"><?php echo e($user->id); ?></th>
                <td><?php echo e($user->name); ?></td>
                <td><?php echo e($user->email); ?></td>
               
                <td>
                    <?php if($user->roles()->get()->pluck('name')->toArray()): ?>
                    SI
                    <?php else: ?>
                    NO
                    <?php endif; ?>
                  
                  
                </td>
                <td>
                  <a href="<?php echo e(route('admin.users.edit', $user->id)); ?> ">
                    <button type="button" class="btn btn-primary btn-sm" data-toggle="tooltip" data-placement="top" title="Editar/Modificar Usuario"><i class="far fa-edit"></i></button>
                  </a>
                  <a data-toggle="tooltip" data-placement="top" title="Eliminar Usuario"><button data-target="#modal-delete-<?php echo e($user->id); ?>" data-toggle="modal"
                    class="btn btn-danger btn-sm"><i class="fas fa-ban"></i></button></a>

              </td>

              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </tbody>
          </table>

        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\cyber\Desktop\tallerfinal\taller\resources\views/admin/users/index.blade.php ENDPATH**/ ?>