<div class="modal fade modal-slide-in-right" aria-hidden="true" role="dialog" tabindex="-1" id="modal-borrado-lista">


    <div class="modal-dialog">
        <div class="modal-content">

            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">X</span>
                </button>
                <h3 class="modal-title">Eliminar Reparaciones Listadas</h3>

            </div>
            <div class="modal-body">
                <p>¿REALMENTE DESEA ELIMINAR ESTAS REPARACIONES DE LA BASE DE DATOS?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">No</button>
               
                <a href="<?php echo e(route('admin.reparation.deleteListadas', $searchText)); ?>">Si Borrar</a>
            </div>
        </div>
    </div>


</div><?php /**PATH C:\Users\cyber\Desktop\tallerfinal\taller\resources\views/admin/reparations/modal2.blade.php ENDPATH**/ ?>