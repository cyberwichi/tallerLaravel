<?php echo Form::open(array('url'=>'admin/admin/reparations', 'method'=>'GET', 'autocomplete'=>'off', 'role'=>'search'
,'class'=>'form-inline')); ?>


<div class="input-group col-12 mt-3">
    <div class="input-group-prepend">
        <button type="submit" class="btn btn-primary input-group-text">Buscar </button>
        <input type="text" id="inlineFormInputGroup" class="form-control col-8" name="searchText"
            placeholder="Buscar..." value="<?php echo e(old($searchText)); ?>">
    </div>
    

</div>
<div class="small text-center ml-3 mb-3">
        <span class=""> Busquedas por fecha en formato AAAA-MM-DD</span>
       

</div>

<?php echo e(Form::close()); ?>

<?php /**PATH C:\Users\cyber\Desktop\tallerfinal\taller\resources\views/admin/reparations/search.blade.php ENDPATH**/ ?>