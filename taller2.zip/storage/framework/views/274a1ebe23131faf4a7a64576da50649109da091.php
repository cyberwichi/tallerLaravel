<div class="modal fade modal-slide-in-right" aria-hidden="true" role="dialog" tabindex="-1"
    id="modal-delete-<?php echo e($user->id); ?>">
    <?php echo Form::open(['route' => ['admin.users.destroy', $user->id], 'method' => 'DELETE', 'class' => 'pull-right']); ?>

 
    <div class="modal-dialog">
        <div class="modal-content">

            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">X</span>
                </button>
                <h3 class="modal-title">Eliminar Usuario</h3>

            </div>
            <div class="modal-body">
                <p>¿REALMENTE DESEA ELIMINAR ESTE USUARIO DE LA BASE DE DATOS?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">No</button>
                <button type="submit" class="btn btn-primary">Si Borrar</button>

            </div>
        </div>
    </div>
    <?php echo e(Form::Close()); ?>


</div><?php /**PATH C:\Users\cyber\Desktop\tallerfinal\taller\resources\views/admin/users/modal.blade.php ENDPATH**/ ?>