window.onload=function(){
    console.log("aqui");
    $('#spiner').fadeOut();
};

$('a').click(function(){
    console.log("aqui 2");
    $('#spiner').fadeIn();
});
$('#submit').click(function(){
    console.log("aqui 2");
    $('#spiner').fadeIn();
});

