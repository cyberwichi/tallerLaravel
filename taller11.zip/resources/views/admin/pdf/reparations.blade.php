<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Listado de Reparaciones</title>
    <style>
    .table{
        width: 100%;
        border: 1px solid #000000; 
    }
    .linea{
        border: 1px solid #000000; 

    }
   
    
    </style>
</head>
<body>
        <h2>Listado de Reparaciones</h2>
        <table class="" >
            
                
                <thead class="table">
                   
                    <tr>
                    <th >ID</th>
                    <th>Matricula</th>
                    <th>Codigo</th>
                    <th >Reparacion</th>
                    <th > Fecha </th>
                    <th>Kilometros</th> 
                    </tr>                              
                </thead>
                <tbody>
                       @foreach ($reparations as $reparation)  
                              
                        <tr  >
                         <?php
                                    $matr=Str_split($reparation->matricula ,1);
                                    $final="";
                                    for ($a=0;$a<count($matr);$a++){
                                        $final .= ord($matr[$a]).'*';		
                                    }
                                    ?> 
                                <td>{{$reparation->id}} </td>
                                <td>{{$reparation->matricula}} </td>
                                <td>{{$final}} </td>
                                <td>{{$reparation->desrepara}} </td>
                                <td>{{Carbon::parse($reparation->fecha)->formatLocalized('%d %m %Y')}} </td>
                                <td>{{$reparation->kilometros}} </td>

                           
                        </tr>
                        
                        @endforeach
        


                </tbody>

               
                
            </table>

    
</body>
</html>